# Login en PHP y MySQL

En este proyecto utilizamos varios componentes, para la parte visual se usa Bootstrap, para las alertas utilizamos SweetAlert y para los iconos utilizamos Font Awesome, recuerda que tanto Bootstrap como SweetAlert requieren de jquery para funcionar (el proyecto usa la version 3.1.1 de jquery).[![](https://3.bp.blogspot.com/-ZOhb8Hkzzzs/XHjDtuP0BcI/AAAAAAAAN1M/0lFpbtg7CLU3WzrWOlius9z9OkrLkSQ-ACLcBGAs/s1600/Login.png)](https://www.lpericena.tk/2018/06/login-y-registro-con-php-y-base-de.html)
https://lpericena.blogspot.com/
El login valida que el usuario y la clave sean correctas, agregue una animacion que se muestra mientras el cliete espera una respuesta del servidor, normalmente en local no se nota pero cuando el proyecto se sube a un servidor real el load si tiene tiempo de mostrarse, agregue ademas el manejo de roles, ademas las paginas donde se redirecciona valida si la sesion iniciada tiene permisos para ver la pagina, para finalizar agregue un boton de cerrar sesion, y el archivo de index donde esta el login valida si existe una sesion y si es asi redirecciona a la pagina que corresponde la sesion. 

# Usuario de prueba
user:  codigoadsi@gmail.com 
clave: 123

https://lpericena.blogspot.com/
